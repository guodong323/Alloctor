//
//  main.c
//  cmz_allocator
//
//  Designed by [cjh mgd zzx] on 2022/6/5.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
